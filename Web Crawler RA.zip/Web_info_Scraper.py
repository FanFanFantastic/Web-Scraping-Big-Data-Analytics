import requests
from bs4 import BeautifulSoup

#subject to change for the web data source url
url = "https://www.tripadvisor.com/Restaurant_Review-g31377-d334357-Reviews-Four_Peaks_Restaurant-Tempe_Arizona.html"
url_page2 = "https://www.tripadvisor.com/Restaurant_Review-g31377-d334357-Reviews-or10-Four_Peaks_Restaurant-Tempe_Arizona.html#REVIEWS"

r = requests.get(url)
r2 = requests.get(url_page2)

soup = BeautifulSoup(r.content,"html.parser")
#soup = BeautifulSoup(r2.content)

#print(soup.prettify())

#links = soup.find_all("a")

#For finding all review content titles:
review_content_title = soup.find_all("span",{"class":"noQuotes"})

#For finding all review contents:
review_content = soup.find_all("div",{"class":"entry"})

#For finding review stars
review_star = soup.find_all("img",{"class":"sprite-rating_s_fill"})

#For finding review times
review_time = soup.find_all("span",{"class":"ratingDate"})

#For finding user name
user_names = soup.find_all("div",{"class","username"})

#For finding user levels
user_levels = soup.find_all("div",{"class","levelBadge"})

#For finding user reviews
user_review_num = soup.find_all("span",{"class","badgeText"})

#For finding user member time
user_mem_time = soup.find_all("ul",{"class","memberdescription"})

#Making things easier to read

for item in review_time:#user_mem_time:#user_review_num:#user_levels:#user_names:#review_time:#review_star:#review_content:#review_content_title:
	item.get("title")   #print(item.content[1].text)#print(item.text)#item.get("class")#print(item.text)#item.get("title")    #item.get("alt") #print(item.text,";")  #semi colon for Excel separation(later use)
	print(item.text)
