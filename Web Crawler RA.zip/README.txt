All collected Data are stored in the "Content_Varibales" folder for further excel input analysis

Demonstration and Guide are provided in the Word Document



-------Made by Jiongming Fan-------------